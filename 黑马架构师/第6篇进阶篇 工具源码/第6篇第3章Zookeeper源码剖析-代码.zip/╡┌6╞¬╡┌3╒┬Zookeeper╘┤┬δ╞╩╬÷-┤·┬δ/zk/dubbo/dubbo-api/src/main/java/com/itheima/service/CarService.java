package com.itheima.service;

/*****
 * @Author:
 * @Description:
 ****/
public interface CarService {

    //车辆信息获取
    String cartInfo(String name);
}
