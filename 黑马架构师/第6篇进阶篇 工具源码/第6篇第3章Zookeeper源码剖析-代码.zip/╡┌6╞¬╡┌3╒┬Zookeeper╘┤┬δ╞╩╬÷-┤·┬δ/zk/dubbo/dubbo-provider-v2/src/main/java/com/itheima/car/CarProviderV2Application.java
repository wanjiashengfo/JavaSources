package com.itheima.car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*****
 * @Author:
 * @Description:
 ****/
@SpringBootApplication
public class CarProviderV2Application {

    public static void main(String[] args) {
        SpringApplication.run(CarProviderV2Application.class,args);
    }
}
