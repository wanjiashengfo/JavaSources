package com.czbk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGrayApplicationTests {

    @Test
    void contextLoads() {
    }

}
