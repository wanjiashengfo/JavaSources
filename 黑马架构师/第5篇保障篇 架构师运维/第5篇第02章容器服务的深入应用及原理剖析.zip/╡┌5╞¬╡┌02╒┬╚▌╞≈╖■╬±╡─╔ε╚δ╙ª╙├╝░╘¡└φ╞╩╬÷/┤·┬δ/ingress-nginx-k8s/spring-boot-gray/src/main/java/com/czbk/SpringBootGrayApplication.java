package com.czbk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Class: SpringBootGrayApplication
 * @Package com.czbk
 * @Description:灰度版本
 * @Company: http://www.itheima.com/
 */
@SpringBootApplication
@RestController
public class SpringBootGrayApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootGrayApplication.class, args);
    }

    @GetMapping(path = "/", produces = "application/json")
    public String get() {
        return "Name:spring-boot-gray";

    }

}
