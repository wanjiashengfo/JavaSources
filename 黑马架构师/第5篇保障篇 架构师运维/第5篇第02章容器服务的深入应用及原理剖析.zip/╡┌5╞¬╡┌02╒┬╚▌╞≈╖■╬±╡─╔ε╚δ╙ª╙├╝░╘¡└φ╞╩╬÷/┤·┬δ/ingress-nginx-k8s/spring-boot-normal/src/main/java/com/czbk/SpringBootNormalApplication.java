package com.czbk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Class: SpringBootNormalApplication
 * @Package com.czbk
 * @Description:正常版本
 * @Company: http://www.itheima.com/
 */
@SpringBootApplication
@RestController
public class SpringBootNormalApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootNormalApplication.class, args);
    }

    @GetMapping(path = "/", produces = "application/json")
    public String get() {
        return "Name:spring-boot-normal";

    }

    @GetMapping(path = "/get", produces = "application/json")
    public String test() {
        return "Name:spring-boot-normal";

    }

}
