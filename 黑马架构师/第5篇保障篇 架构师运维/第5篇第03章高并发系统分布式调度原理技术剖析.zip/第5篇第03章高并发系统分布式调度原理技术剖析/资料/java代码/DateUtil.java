package cn.itcast.util;

import org.apache.commons.lang3.time.DateUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DataUtil {
    /**
     * 将传递的日期拆分成24个时间段
     * @param date
     * @return
     */
    public static List<Date> getDateMenus(Date date) {
        List<Date> dateList = new ArrayList<>();
        for (int i = 0; i < 24; i++) {
            Date d = DateUtils.addHours(date, i);
            dateList.add(d);
        }

        return dateList;
    }

    public static void main(String[] args) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY,0);
        calendar.set(Calendar.MINUTE,0);
        calendar.set(Calendar.SECOND,0);
        List<Date> dateList = getDateMenus(calendar.getTime());
        dateList.forEach((s)->{
            System.out.println(s);
        });
    }
}
